from fastapi.testclient import TestClient
import main

client = TestClient(main.app)


def test_health():
    response = client.get("/health")
    assert response.status_code == 200
    assert response.json()["status"] == "ok"


def test_home():
    response = client.get("/")
    assert response.status_code == 200
    assert "EduGenie" in response.text


def test_qa(monkeypatch):
    monkeypatch.setattr(main, "answer_question", lambda q: "Pacific Ocean")
    response = client.post("/qa", json={"question": "Largest ocean?"})
    assert response.status_code == 200
    assert response.json()["answer"] == "Pacific Ocean"


def test_explain(monkeypatch):
    monkeypatch.setattr(main, "explain_concept", lambda t: "Simple explanation")
    response = client.post("/explain", json={"topic": "Photosynthesis"})
    assert response.status_code == 200
    assert response.json()["explanation"] == "Simple explanation"


def test_summary(monkeypatch):
    monkeypatch.setattr(main, "summarize_text", lambda t: "Short summary")
    response = client.post("/summarize", json={"text": "A useful educational passage."})
    assert response.status_code == 200
    assert response.json()["summary"] == "Short summary"


def test_learning_path(monkeypatch):
    monkeypatch.setattr(main, "get_learning_recommendations", lambda t: "1. Basics")
    response = client.post("/learn/recommendations", json={"topic": "SQL"})
    assert response.status_code == 200
    assert "Basics" in response.json()["recommendations"]


def test_quiz(monkeypatch):
    payload = {
        "questions": [
            {
                "question": "2 + 2?",
                "options": ["1", "2", "3", "4"],
                "correct_answer": "4",
                "explanation": "Two plus two equals four."
            },
            {
                "question": "Capital of France?",
                "options": ["Paris", "Rome", "Berlin", "Madrid"],
                "correct_answer": "Paris",
                "explanation": "Paris is the capital of France."
            },
            {
                "question": "Water formula?",
                "options": ["CO2", "H2O", "O2", "NaCl"],
                "correct_answer": "H2O",
                "explanation": "Water is H2O."
            },
        ]
    }
    monkeypatch.setattr(main, "generate_quiz", lambda t: payload)
    response = client.post("/quiz", json={"text": "Basic science and mathematics."})
    assert response.status_code == 200
    assert len(response.json()["questions"]) == 3
