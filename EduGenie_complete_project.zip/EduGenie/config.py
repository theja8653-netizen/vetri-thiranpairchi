import os
from functools import lru_cache
from pathlib import Path

from dotenv import load_dotenv

BASE_DIR = Path(__file__).resolve().parent
load_dotenv(BASE_DIR / ".env")


@lru_cache
def get_settings():
    return {
        "gemini_api_key": os.getenv("GEMINI_API_KEY", "").strip(),
        "gemini_model": os.getenv("GEMINI_MODEL", "gemini-2.5-flash").strip(),
        "explanation_backend": os.getenv("EXPLANATION_BACKEND", "gemini").strip().lower(),
        "local_explanation_model": os.getenv(
            "LOCAL_EXPLANATION_MODEL",
            "MBZUAI/LaMini-Flan-T5-783M",
        ).strip(),
        "max_output_tokens": int(os.getenv("MAX_OUTPUT_TOKENS", "1200")),
        "temperature": float(os.getenv("TEMPERATURE", "0.3")),
    }
