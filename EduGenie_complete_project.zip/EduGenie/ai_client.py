from functools import lru_cache

from google import genai
from google.genai import types

from config import get_settings


class AIConfigurationError(RuntimeError):
    pass


@lru_cache
def get_gemini_client():
    settings = get_settings()
    api_key = settings["gemini_api_key"]
    if not api_key:
        raise AIConfigurationError(
            "GEMINI_API_KEY is missing. Add it to the .env file."
        )
    return genai.Client(api_key=api_key)


def generate_text(prompt: str, system_instruction: str | None = None) -> str:
    settings = get_settings()
    client = get_gemini_client()

    config = types.GenerateContentConfig(
        system_instruction=system_instruction,
        temperature=settings["temperature"],
        max_output_tokens=settings["max_output_tokens"],
    )

    response = client.models.generate_content(
        model=settings["gemini_model"],
        contents=prompt,
        config=config,
    )

    text = getattr(response, "text", None)
    if not text:
        raise RuntimeError("Gemini returned an empty response.")
    return text.strip()


def generate_structured(prompt: str, schema):
    settings = get_settings()
    client = get_gemini_client()

    config = types.GenerateContentConfig(
        response_mime_type="application/json",
        response_schema=schema,
        temperature=settings["temperature"],
        max_output_tokens=settings["max_output_tokens"],
    )

    response = client.models.generate_content(
        model=settings["gemini_model"],
        contents=prompt,
        config=config,
    )

    parsed = getattr(response, "parsed", None)
    if parsed is not None:
        return parsed

    text = getattr(response, "text", None)
    if not text:
        raise RuntimeError("Gemini returned no structured response.")

    return schema.model_validate_json(text)
