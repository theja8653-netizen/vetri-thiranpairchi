from config import get_settings
from ai_client import generate_text


def _gemini_explanation(topic: str) -> str:
    prompt = f"""
Explain the following topic to a beginner:

{topic}

Use this structure:
- Simple definition
- How it works
- One easy example
- Key points to remember

Avoid unnecessary jargon.
"""
    return generate_text(prompt, """
You are EduGenie, an expert teacher who explains complex topics simply.
Your response must be accurate, beginner-friendly, and concise.
""")


def _local_explanation(topic: str) -> str:
    try:
        from transformers import pipeline
    except ImportError as exc:
        raise RuntimeError(
            "Local explanation backend requires transformers and torch. "
            "Install requirements-local.txt or use EXPLANATION_BACKEND=gemini."
        ) from exc

    settings = get_settings()

    # Lazy loading keeps application startup lightweight. The model is downloaded
    # only when the first local explanation is requested.
    if not hasattr(_local_explanation, "_pipeline"):
        _local_explanation._pipeline = pipeline(
            "text2text-generation",
            model=settings["local_explanation_model"],
        )

    prompt = (
        "Explain this topic simply for a beginner. Give a definition, "
        "how it works, one example, and key points: " + topic
    )
    result = _local_explanation._pipeline(
        prompt,
        max_new_tokens=180,
        do_sample=False,
    )
    return result[0]["generated_text"].strip()


def explain_concept(topic: str) -> str:
    backend = get_settings()["explanation_backend"]

    if backend == "local":
        return _local_explanation(topic)

    if backend != "gemini":
        raise RuntimeError(
            "EXPLANATION_BACKEND must be either 'gemini' or 'local'."
        )

    return _gemini_explanation(topic)
