from ai_client import generate_text

SYSTEM_PROMPT = """
You are EduGenie, a friendly educational assistant.
Answer academic questions accurately and concisely.
Explain difficult ideas in simple language suitable for a learner.
If the question is ambiguous, state the assumption you are making.
Do not invent citations, sources, statistics, or facts.
"""


def answer_question(question: str) -> str:
    prompt = f"""
Answer the following student question.

Question:
{question}

Requirements:
- Give the direct answer first.
- Then provide a short explanation if useful.
- Use simple language.
- Prefer bullets or numbered steps for processes.
"""
    return generate_text(prompt, SYSTEM_PROMPT)
