from ai_client import generate_text

SYSTEM_PROMPT = """
You are EduGenie's learning-path designer.
Create practical educational plans from beginner to advanced.
Be realistic about prerequisites and progression.
Recommend resource types or well-known resource names, but do not fabricate
URLs or claim a resource was verified unless it was actually checked.
"""


def get_learning_recommendations(topic: str) -> str:
    prompt = f"""
Create a structured learning path for: {topic}

Include:
- Prerequisites
- Beginner stage
- Intermediate stage
- Advanced stage
- Suggested timeline
- Practice/project ideas
- Recommended resource types (courses, documentation, books, videos)
- A simple weekly routine
- How the learner can check their progress

Adapt the plan for a student who may be starting from zero.
"""
    return generate_text(prompt, SYSTEM_PROMPT)
