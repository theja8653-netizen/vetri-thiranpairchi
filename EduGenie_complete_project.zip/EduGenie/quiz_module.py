from pydantic import BaseModel, Field

from ai_client import generate_structured


class QuizQuestionSchema(BaseModel):
    question: str = Field(description="A clear multiple-choice question.")
    options: list[str] = Field(
        description="Exactly four answer choices.",
        min_length=4,
        max_length=4,
    )
    correct_answer: str = Field(
        description="Exactly one of the four option strings."
    )
    explanation: str = Field(
        description="A short explanation of why the correct answer is correct."
    )


class QuizSchema(BaseModel):
    questions: list[QuizQuestionSchema] = Field(
        description="Exactly three multiple-choice questions.",
        min_length=3,
        max_length=3,
    )


def generate_quiz(text: str) -> dict:
    prompt = f"""
Create exactly 3 multiple-choice questions from the supplied educational text.

TEXT:
{text}

Rules:
- Exactly 3 questions.
- Exactly 4 options per question.
- Only one correct answer.
- correct_answer must exactly match one option.
- Distractors should be plausible but incorrect.
- Questions must be answerable from the supplied text.
- Avoid trick questions.
- Include a short explanation for each answer.
"""
    result = generate_structured(prompt, QuizSchema)

    # Extra validation because models can occasionally return semantically
    # inconsistent structured data even when the JSON shape is correct.
    for item in result.questions:
        if len(item.options) != 4:
            raise RuntimeError("Quiz generation returned an invalid option count.")
        if item.correct_answer not in item.options:
            raise RuntimeError(
                "Quiz generation returned a correct answer not present in options."
            )

    return result.model_dump()
