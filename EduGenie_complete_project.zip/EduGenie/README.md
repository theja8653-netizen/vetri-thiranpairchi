# EduGenie — Google Gemini Powered Learning Assistant

EduGenie is a FastAPI + HTML/CSS educational assistant based on the supplied project document.

## Features

- Q&A — `/qa`
- Beginner-friendly concept explanation — `/explain`
- Three-question MCQ quiz — `/quiz`
- Educational summarization — `/summarize`
- Beginner-to-advanced learning path — `/learn/recommendations`
- Responsive single-page web interface
- Input validation and useful API errors
- Automated API tests
- Optional local LaMini-Flan-T5 explanation backend

## Architecture

```text
EduGenie/
├── main.py
├── models.py
├── config.py
├── ai_client.py
├── explanation_module.py
├── qna.py
├── quiz_module.py
├── summary_module.py
├── learning_path.py
├── requirements.txt
├── requirements-local.txt
├── .env.example
├── .gitignore
├── templates/
│   └── index.html
├── static/
│   └── style.css
└── tests/
    └── test_api.py
```

## Why the default explanation backend is Gemini

The supplied document specifies LaMini-Flan-T5-783M for local concept explanations and Gemini 1.5 Pro for the other modules. Model availability changes over time, and the current Gemini documentation recommends the newer Google GenAI SDK. This implementation therefore keeps LaMini as an optional, explicitly configured backend while using Gemini as the default explanation backend. This makes the project easier to install and run on ordinary student laptops.

The Gemini model is configurable with `GEMINI_MODEL`; the default is `gemini-2.5-flash`.

## 1. Install Python

Use Python 3.10 or newer.

Verify:

```bash
python --version
```

On Windows, if `python` is not recognized, try:

```bash
py --version
```

## 2. Open the project in VS Code

Open the `EduGenie` folder.

Then open **Terminal → New Terminal**.

## 3. Create a virtual environment

Windows:

```bash
python -m venv .venv
.venv\Scripts\activate
```

macOS/Linux:

```bash
python3 -m venv .venv
source .venv/bin/activate
```

## 4. Install dependencies

```bash
python -m pip install --upgrade pip
pip install -r requirements.txt
```

## 5. Add the Gemini API key

Create a file named `.env` beside `main.py`.

Copy `.env.example` into `.env`, then put your Google AI Studio API key into:

```env
GEMINI_API_KEY=your_real_key_here
```

Do not commit `.env` to Git; it is ignored by `.gitignore`.

## 6. Run the application

```bash
uvicorn main:app --reload
```

Open:

```text
http://127.0.0.1:8000
```

API documentation is available at:

```text
http://127.0.0.1:8000/docs
```

Health check:

```text
http://127.0.0.1:8000/health
```

## 7. Test from the browser

Try these examples:

### Ask a question
Task: Ask a Question

```text
Which is the largest ocean?
```

### Explain
Task: Explain a Topic

```text
Explain the Pythagoras theorem for a beginner.
```

### Quiz
Task: Generate Quiz

Paste:

```text
The water cycle describes the continuous movement of water on Earth.
Evaporation changes liquid water into water vapour because of heat.
Condensation changes water vapour into tiny liquid droplets.
Precipitation occurs when water falls from clouds as rain, snow, sleet, or hail.
```

The app should generate exactly three questions with four choices each.

### Summary

Paste any educational paragraph.

### Learning path

```text
SQL from beginner to advanced
```

## 8. Run automated tests

Install pytest:

```bash
pip install pytest
```

Then:

```bash
pytest -q
```

The tests mock the AI layer, so they do not consume Gemini API quota.

## 9. Optional: use the document's local LaMini model

The original project documentation specifies `LaMini-Flan-T5-783M` for concept explanation.

Install its optional dependencies:

```bash
pip install -r requirements-local.txt
```

Change `.env`:

```env
EXPLANATION_BACKEND=local
LOCAL_EXPLANATION_MODEL=MBZUAI/LaMini-Flan-T5-783M
```

Restart Uvicorn.

The first local explanation may take time because the model must be downloaded and loaded. CPU inference can also be significantly slower than Gemini.

To return to the easier/default setup:

```env
EXPLANATION_BACKEND=gemini
```

## API examples

### Q&A

```bash
curl -X POST http://127.0.0.1:8000/qa ^
  -H "Content-Type: application/json" ^
  -d "{\"question\":\"What is photosynthesis?\"}"
```

macOS/Linux:

```bash
curl -X POST http://127.0.0.1:8000/qa \
  -H "Content-Type: application/json" \
  -d '{"question":"What is photosynthesis?"}'
```

### Explanation

```bash
curl -X POST http://127.0.0.1:8000/explain \
  -H "Content-Type: application/json" \
  -d '{"topic":"Pythagoras theorem"}'
```

### Quiz

```bash
curl -X POST http://127.0.0.1:8000/quiz \
  -H "Content-Type: application/json" \
  -d '{"text":"The Earth revolves around the Sun."}'
```

## Troubleshooting

### `GEMINI_API_KEY is missing`

Make sure `.env` exists in the same folder as `main.py` and contains:

```env
GEMINI_API_KEY=...
```

Restart Uvicorn after changing `.env`.

### `ModuleNotFoundError`

Activate the virtual environment and run:

```bash
pip install -r requirements.txt
```

### Port 8000 already in use

Run:

```bash
uvicorn main:app --reload --port 8001
```

Then open `http://127.0.0.1:8001`.

### Gemini model error

Change `GEMINI_MODEL` in `.env` to a model currently available to your API key. The application does not hard-code the model in Python.

### Local model is too slow

Use:

```env
EXPLANATION_BACKEND=gemini
```

The local model is intentionally optional.

## Security notes

- Never put your API key into `index.html` or JavaScript.
- Never commit `.env`.
- The browser calls your FastAPI server; only the server communicates with Gemini.
- For production deployment, add authentication, rate limiting, logging controls, HTTPS, and a persistent user-data policy before storing student information.
