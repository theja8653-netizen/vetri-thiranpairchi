from ai_client import generate_text

SYSTEM_PROMPT = """
You are EduGenie's summarization assistant.
Create accurate, easy-to-revise educational summaries.
Preserve important facts, definitions, relationships, and conclusions.
Never add information that is not supported by the supplied text.
"""


def summarize_text(text: str) -> str:
    prompt = f"""
Summarize the following educational passage.

PASSAGE:
{text}

Return:
1. A concise summary.
2. 3-7 key points.
3. Important terms or definitions when present.

Keep the result clear and useful for revision.
"""
    return generate_text(prompt, SYSTEM_PROMPT)
