from pydantic import BaseModel, Field, field_validator


class TextRequest(BaseModel):
    text: str = Field(..., min_length=3, max_length=20000)

    @field_validator("text")
    @classmethod
    def clean_text(cls, value: str) -> str:
        value = value.strip()
        if len(value) < 3:
            raise ValueError("Please enter at least 3 characters.")
        return value


class QARequest(BaseModel):
    question: str = Field(..., min_length=3, max_length=5000)

    @field_validator("question")
    @classmethod
    def clean_question(cls, value: str) -> str:
        value = value.strip()
        if not value:
            raise ValueError("Question cannot be empty.")
        return value


class ExplanationRequest(BaseModel):
    topic: str = Field(..., min_length=2, max_length=5000)

    @field_validator("topic")
    @classmethod
    def clean_topic(cls, value: str) -> str:
        return value.strip()


class QuizRequest(TextRequest):
    pass


class SummaryRequest(TextRequest):
    pass


class LearningPathRequest(BaseModel):
    topic: str = Field(..., min_length=2, max_length=5000)

    @field_validator("topic")
    @classmethod
    def clean_topic(cls, value: str) -> str:
        return value.strip()


class QuizQuestion(BaseModel):
    question: str
    options: list[str] = Field(min_length=4, max_length=4)
    correct_answer: str
    explanation: str


class QuizResponse(BaseModel):
    questions: list[QuizQuestion] = Field(min_length=3, max_length=3)


class ErrorResponse(BaseModel):
    error: str
